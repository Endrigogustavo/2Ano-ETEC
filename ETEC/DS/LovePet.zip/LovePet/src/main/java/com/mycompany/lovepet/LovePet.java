/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lovepet;

import java.awt.Color;
import java.awt.Container;
import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;
public class LovePet extends JFrame{
    JLabel img;
    JButton logar;
    public LovePet(){
    super("LovePet");
    
        
        Container tela = getContentPane();
        
        setTitle("LovePet");
        setResizable(false);
        tela.setLayout(null);
        
          
        Color button = new Color(91,194,217);  
        
        
        
        ImageIcon fun = new ImageIcon("src/Img/fun.jpg");
        img = new JLabel(fun);
        img.setBounds(0,0, 1253, 863);
        
        logar = new JButton("Entrar");
        logar.setBounds(540, 650, 190, 30);
        
        
        
        tela.add(logar);
        tela.add(img);
                setSize(1253, 863);
        setVisible(true);
        setLocationRelativeTo(null);
        
}
    

    public static void main(String[] args) {
        LovePet lov = new LovePet();
        lov.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   try {
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (UnsupportedLookAndFeelException e) {

            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();

        } catch (ClassNotFoundException e) {

            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();

        } catch (InstantiationException e) {

            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();

        } catch (IllegalAccessException e) {

            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();
        }

    }

}
